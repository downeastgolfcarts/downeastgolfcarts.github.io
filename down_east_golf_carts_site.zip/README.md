# Down East Golf Carts — Single Page Site

Minimal credibility site with your logo and contact info.

## Edit
- Update text in `index.html` if needed.
- Replace colors in `styles.css` (CSS variables at the top).
- The logo file is `assets/logo.png`.

## Publish Free (GitHub Pages)
1. Create a GitHub account and new repo named `yourusername.github.io`.
2. Upload all files in this folder.
3. In **Settings → Pages**, set the source to `main` branch `/root`.
4. Your site will be at `https://yourusername.github.io`.

### Point Your GoDaddy Domain
In GoDaddy → **Domain → DNS**, add:
- **CNAME**
  - Host: `www`
  - Points to: `yourusername.github.io`

(Optional for apex `yourdomain.com`):
- **A records** to GitHub:
  - `@` → `185.199.108.153`
  - `@` → `185.199.109.153`
  - `@` → `185.199.110.153`
  - `@` → `185.199.111.153`

Create a file named `CNAME` in your repo with:
```
www.yourdomain.com
```

## Netlify (Also Free)
- Drag-and-drop this folder at Netlify → add custom domain `www.yourdomain.com`.
- In GoDaddy DNS, set `www` CNAME to your `*.netlify.app`.

## Contact Links
- Phone: tel:+19197562422
- Email: mailto:downeastgolfcarts@outlook.com
- Maps link opens the address in Apple Maps.
