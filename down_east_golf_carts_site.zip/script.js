const menuBtn=document.getElementById('menuBtn');
const nav=document.getElementById('nav');
if(menuBtn){
  menuBtn.addEventListener('click',()=>{
    const expanded=menuBtn.getAttribute('aria-expanded')==='true';
    menuBtn.setAttribute('aria-expanded',String(!expanded));
    nav.classList.toggle('open');
  });
}
document.getElementById('year').textContent=new Date().getFullYear();
